window['globalThis'] = window['bootstrap']._originalGlobalThis;
window['bootstrap']._originalGlobalThis = null;

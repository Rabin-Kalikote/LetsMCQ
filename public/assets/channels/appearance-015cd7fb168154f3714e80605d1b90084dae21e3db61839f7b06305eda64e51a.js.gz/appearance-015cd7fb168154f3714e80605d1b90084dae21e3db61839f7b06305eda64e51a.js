$(document).ready(function() {
  App.appearance = App.cable.subscriptions.create("AppearanceChannel", {

    // Called when the subscription is
    // ready for use on the server.
    connected: function(data) {
      // console.log("Appearing Online.");

    },

    // Called when the subscription has
    // been terminated by the server.
    disconnected: function() {
      // console.log("Appearing Offline.");
    },

    // Called when there's incoming data
    //on the websocket for this channel.
    received: function(data) {
      // console.log("Broadcasted Online Presence.");
      $('#online-count').text(data['users'] + " Users Online.");
    },
  });
});
